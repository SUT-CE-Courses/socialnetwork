import sys
import heapq
import os

def mafia_dijkstra(n, graph, mafia_positions, car_set):
    INF = float('inf')
    d0 = [INF] * n
    d1 = [INF] * n
    pq = []
    
    for r in mafia_positions:
        if 0 < d0[r]:
            d0[r] = 0
            heapq.heappush(pq, (0, r, 0))
    
    while pq:
        cur_time, u, mode = heapq.heappop(pq)
        if mode == 0 and cur_time > d0[u]:
            continue
        if mode == 1 and cur_time > d1[u]:
            continue
        if mode == 0 and u in car_set:
            if cur_time < d1[u]:
                d1[u] = cur_time
                heapq.heappush(pq, (cur_time, u, 1))
        for v, t in graph[u]:
            if mode == 0:
                new_time = cur_time + t
                if new_time < d0[v]:
                    d0[v] = new_time
                    heapq.heappush(pq, (new_time, v, 0))
            else:
                new_time = cur_time + t / 2.0
                if new_time < d1[v]:
                    d1[v] = new_time
                    heapq.heappush(pq, (new_time, v, 1))
    
    mafia_time = [min(d0[i], d1[i]) for i in range(n)]
    return mafia_time

def tintin_dijkstra(n, graph, start, mafia_time):
    INF = float('inf')
    dist = [INF] * n
    dist[start] = 0
    pq = []
    heapq.heappush(pq, (0, start))
    while pq:
        cur_time, u = heapq.heappop(pq)
        if cur_time > dist[u]:
            continue
        for v, t in graph[u]:
            new_time = cur_time + t
            if new_time < mafia_time[v] and new_time < dist[v]:
                dist[v] = new_time
                heapq.heappush(pq, (new_time, v))
    return dist

def main():
    n, m = map(int, input().split())
    
    graph = [[] for _ in range(n)]
    for _ in range(m):
        u, v, t = map(int, input().split())
        graph[u].append((v, t))
        graph[v].append((u, t))
    
    k = int(input())
    mafia_positions = [int(input()) for _ in range(k)]
    
    c = int(input())
    car_positions = [int(input()) for _ in range(c)]
    car_set = set(car_positions)
    
    dest, start = map(int, input().split())
    
    mafia_time = mafia_dijkstra(n, graph, mafia_positions, car_set)
    tintin_time = tintin_dijkstra(n, graph, start, mafia_time)
    
    if tintin_time[dest] < mafia_time[dest]:
        print("tintin")
    else:
        print("mafia")

if __name__ == "__main__":
    main()
